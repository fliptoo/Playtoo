package models.Playtoo.json;

import models.Playtoo.db.UserID;

public class JUser extends JUserID {

	public JUser(UserID user) {
		super(user);
	}

}
