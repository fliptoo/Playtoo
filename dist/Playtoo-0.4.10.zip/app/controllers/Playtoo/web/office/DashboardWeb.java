package controllers.Playtoo.web.office;

import controllers.Playtoo.BaseOffice;

public class DashboardWeb extends BaseOffice {

	public static void index() {
		render();
	}
}
